# Feelings Matter — React recreation

A responsive React + Vite recreation of the Feelings Matter educational website.

## Features
- Responsive navigation and landing page
- Emotion explorer with eight selectable emotions and coping reminders
- Express Your Emotions card maker with feeling selection, editable message, sticker decorations, background color choices, and SVG download
- Myth-or-Fact quiz with answer feedback and progress
- Rotating affirmations
- Self-care activities: paced breathing animation, virtual hug, and 5–4–3–2–1 grounding guide
- Mental-health awareness story and external resource link

## Run locally
1. Install Node.js (LTS).
2. Extract this folder.
3. Open a terminal in this folder.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local URL printed by Vite (usually http://localhost:5173).

## Build
Run `npm run build`. The production website will be in `dist/`.

## GitHub
Create a new GitHub repository, then upload the contents of this folder (not the ZIP itself). Alternatively:
```bash
git init
git add .
git commit -m "Create Feelings Matter React website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/feelings-matter-react.git
git push -u origin main
```

## Notes on fidelity
The original hosted page could not be fetched by the file-generation runtime during this session. This project is a fresh recreation based on the features and design details described in the conversation, not a download of the original private source. Some visual details, copy, or page sections may differ from the hosted website. Replace/add assets in `src/` as needed if you provide screenshots or original images.
